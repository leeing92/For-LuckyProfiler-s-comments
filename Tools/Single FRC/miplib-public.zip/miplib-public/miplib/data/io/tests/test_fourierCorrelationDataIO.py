from unittest import TestCase


class TestFourierCorrelationDataIO(TestCase):


    pass
